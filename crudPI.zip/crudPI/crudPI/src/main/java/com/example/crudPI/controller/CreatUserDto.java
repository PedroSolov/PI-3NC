package com.example.crudPI.controller;

public record CreatUserDto(String name, String email, String password, String cep, String phone, String cpf) {
}
