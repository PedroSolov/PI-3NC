package com.example.crudPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudPiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudPiApplication.class, args);
	}

}
