package com.example.crudPI.service;

import com.example.crudPI.controller.CreatUserDto;
import com.example.crudPI.entity.User;
import com.example.crudPI.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

@Service
public class UserService {

    private UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public UUID createUser(CreatUserDto creatUserDto) {

        // DTO -> ENTITY

        var entity = new User(UUID.randomUUID(),
                creatUserDto.name(),
                creatUserDto.email(),
                creatUserDto.password(),
                creatUserDto.cep(),
                creatUserDto.phone(),
                creatUserDto.cpf(),
                Instant.now(),
                null);

        var userSaved = userRepository.save(entity);
        return userSaved.getUserId();
    }
}
